#!/bin/bash

while true; do
  echo "Iniciando index..."
  
  node index.js
  
  echo "Bot fechou. Reiniciando em 3 segundos..."
  sleep 3
done