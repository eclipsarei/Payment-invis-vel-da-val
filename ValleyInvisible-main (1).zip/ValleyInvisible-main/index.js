const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, Browsers, DisconnectReason } = require('@whiskeysockets/baileys')
const pino = require('pino')
const readline = require('readline')
const { Boom } = require('@hapi/boom')
const fs = require('fs')
const path = require('path')

const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => new Promise((resolve) => rl.question(text, resolve))

let client = null
let isConnected = false
let jaPareou = false

// Carrega comandos da pasta commands/
const commands = new Map()
const commandsDir = path.join(__dirname, 'commands')

if (fs.existsSync(commandsDir)) {
  const files = fs.readdirSync(commandsDir).filter(f => f.endsWith('.js'))
  for (const file of files) {
    const cmd = require(path.join(commandsDir, file))
    if (cmd.name) {
      commands.set(cmd.name, cmd)
      console.log(`[CMD] Comando carregado: ${cmd.name}`)
    }
  }
}

async function ligarbot() {
  const { state, saveCreds } = await useMultiFileAuthState('./sessao')
  let version
  try {
    const fetch = await fetchLatestBaileysVersion()
    version = fetch.version
    console.log(`[BOT] Usando versão dinâmica: ${version.join('.')}`)
  } catch {
    version = [2, 2416, 8]
    console.log(`[BOT] Usando versão fallback: ${version.join('.')}`)
  }

  client = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: 'silent' }),
    browser: Browsers.ubuntu('Chrome'),
    printQRInTerminal: false
  })

  client.ev.on('creds.update', saveCreds)

  client.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update

    if (qr && !client.authState.creds.registered && !jaPareou) {
      jaPareou = true
      const Pergunta = await question('📱 Digite seu número com DDI: ')
      const Numero = Pergunta.replace(/[^0-9]/g, '')
      let codigo = await client.requestPairingCode(Numero)
      codigo = codigo?.match(/.{1,4}/g)?.join('-') || codigo
      console.log(`🔑 Código de Pareamento: ${codigo}`)
    }

    if (connection === 'open') {
      console.log('Conexão BoTed fornecida.')
      isConnected = true
    }

    if (connection === 'close') {
      isConnected = false
      const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode
      console.log('Conexão fechada. Código:', statusCode)
      if (statusCode !== DisconnectReason.loggedOut) {
        console.log('Reconectando...')
        setTimeout(ligarbot, 3000)
      } else {
        console.log('Deslogado. Apague a pasta "sessao" e pareie novamente.')
        process.exit(1)
      }
    }
  })

  // Listener de mensagens para comandos
  client.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return

    const msg = messages[0]
    if (!msg?.message || msg.key.fromMe) return

    const body = msg.message.conversation
      || msg.message.extendedTextMessage?.text
      || msg.message.imageMessage?.caption
      || msg.message.videoMessage?.caption
      || ''

    if (!body.startsWith('!')) return

    const args = body.slice(1).trim().split(/\s+/)
    const cmdName = args.shift().toLowerCase()

    const command = commands.get(cmdName)
    if (!command) return

    try {
      await command.execute({
        sock: client,
        msg,
        args,
        body: body.slice(1).trim()
      })
    } catch (err) {
      console.error(`[CMD] Erro no comando ${cmdName}:`, err)
    }
  })
}

;(async () => {
  await ligarbot()
})()
