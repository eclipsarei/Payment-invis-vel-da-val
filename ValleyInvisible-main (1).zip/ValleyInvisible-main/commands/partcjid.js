// commands/partcjid.js
module.exports = {
  name: 'partcjid',
  async execute({ sock, msg, args }) {
    const from = msg.key.remoteJid

    if (from.endsWith('@g.us')) {
      await sock.sendMessage(from, { text: 'Só funciona no PV.' })
      return
    }

    const groupJid = args.join('').trim()

    if (!groupJid || !groupJid.includes('@g.us')) {
      await sock.sendMessage(from, {
        text: 'Use: `!partcjid jidDoGrupo`'
      })
      return
    }

    try {
      const metadata = await sock.groupMetadata(groupJid)
      const participants = metadata.participants || []

      if (participants.length === 0) {
        await sock.sendMessage(from, { text: '📭 Grupo vazio.' })
        return
      }

      let text = `*👥 Membros de ${metadata.subject || groupJid}:*\n\n`

      for (const p of participants) {
        const isAdmin = p.admin === 'admin' || p.admin === 'superadmin'
        const tag = isAdmin ? ' 👑' : ''

        const realJid = p.phoneNumber || p.id
        const num = realJid.split('@')[0]

        let name = ''
        try {
          const contact = await sock.contactQuery(realJid).catch(() => null)
          name = contact?.name || contact?.notify || contact?.vname || ''
        } catch {
        }

        if (!name) {
          const storeContact = sock.contacts?.[realJid]
          name = storeContact?.name || storeContact?.notify || ''
        }

        if (!name) name = num

        text += `${name}${tag}\n`
        text += `\`${realJid}\`\n\n`
      }

      await sock.sendMessage(from, { text })

    } catch (err) {
      console.error('[partcjid] Erro:', err)
      await sock.sendMessage(from, {
        text: `Erro: ${err.message}`
      })
    }
  }
}
