// commands/grupos.js
module.exports = {
  name: 'grupos',
  async execute({ sock, msg }) {
    const from = msg.key.remoteJid

    // Só funciona no PV
    if (from.endsWith('@g.us')) {
      await sock.sendMessage(from, {
        text: 'Este comando só funciona no privado com o bot.'
      })
      return
    }

    try {
      // Pega todos os grupos do bot
      const groups = await sock.groupFetchAllParticipating()

      if (!groups || Object.keys(groups).length === 0) {
        await sock.sendMessage(from, {
          text: '📭 O bot não está em nenhum grupo.'
        })
        return
      }

      let text = '*Grupos que o bot está:*\n\n'

      for (const [jid, group] of Object.entries(groups)) {
        const name = group.subject || 'Sem nome'
        const participantsCount = group.participants?.length || 0
        text += `*${name}*\n`
        text += `JID: \`${jid}\`\n`
        text += `Membros: ${participantsCount}\n\n`
      }

      text += `_Use_ \`!partcjid jidDoGrupo\` _para ver os membros._`

      await sock.sendMessage(from, { text })

    } catch (err) {
      console.error('[GRUPOS] Erro:', err)
      await sock.sendMessage(from, {
        text: `Erro: ${err.message}`
      })
    }
  }
}
