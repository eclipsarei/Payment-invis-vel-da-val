# ValleyInvisible
Valley Invisible é uma base bot desenvolvida por nós do Studio Valley, ela já vem com sistema de mensagens invisíveis, que aparecem apenas para UMA PESSOA do grupo.

# Instalação
Certifique-se de conter o git, npm e node (V20+), instalado para utilizar o comando a seguir:

## Comando de Instalação 
Certifique-se de substituir "VALLEY_INVISIBLE" pela pasta que você usará para o bot.

```cd VALLEY_INVISIBLE && git clone https://github.com/VALLEY-STUDIOS/ValleyInvisible.git . && bash install.sh```

## Comando de Inicialização 
Após inicializar, conecte digitando seu número com código de pais + DDD, e utilize o código para confirmar.

Certifique-se de substituir "VALLEY_INVISIBLE" pela pasta que você instalou o bot.

```cd VALLEY_INVISIBLE && sh start.sh```
