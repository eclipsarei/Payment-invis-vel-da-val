#!/bin/bash

# Verifica Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js não encontrado."
    exit 1
fi

NODE_VERSION=$(node -v | sed 's/v//' | cut -d. -f1)

if [ "$NODE_VERSION" -lt 20 ]; then
    echo "❌ Node.js versão 20+ necessária."
    exit 1
fi

# Verifica npm
if ! command -v npm &> /dev/null; then
    echo "❌ npm não encontrado."
    exit 1
fi

# Verifica Yarn
if ! command -v yarn &> /dev/null; then
    npm install -g yarn

    if ! command -v yarn &> /dev/null; then
        echo "❌ Falha ao instalar Yarn."
        exit 1
    fi
fi

# Instala dependências
yarn --ignore-scripts --no-bin-links --force

if [ $? -ne 0 ]; then
    echo "❌ Erro ao executar Yarn."
    exit 1
fi

echo "✅ Concluído."